#define bool int

void make_empty(); 
bool is_empty(); 
bool is_full();
void push(int); 
int pop(); 
